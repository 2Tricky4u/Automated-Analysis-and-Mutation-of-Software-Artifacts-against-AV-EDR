 #include <windows.h>
  #include <string>

  int main(int argc, char* argv[]) {
      // Build command line for RedEdr.exe
      std::string cmdLine = "C:\\RedEdr\\RedEdr.exe --web";

      // Setup startup info to hide window and redirect output
      STARTUPINFOA si = { sizeof(si) };
      si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
      si.wShowWindow = SW_HIDE;
      si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
      si.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
      si.hStdError = GetStdHandle(STD_ERROR_HANDLE);

      PROCESS_INFORMATION pi = { 0 };

      // Create process
      if (!CreateProcessA(
          NULL,
          (LPSTR)cmdLine.c_str(),
          NULL,
          NULL,
          FALSE,
          CREATE_NO_WINDOW,
          NULL,
          "C:\\RedEdr",
          &si,
          &pi
      )) {
          return GetLastError();
      }

      // Don't wait - let it run independently
      CloseHandle(pi.hProcess);
      CloseHandle(pi.hThread);

      return 0;
  }