  #include <windows.h>
  #include <string>
  #include <fstream>

  void Log(const char* message, DWORD error = 0) {
      std::ofstream log("C:\\RedEdr\\wrapper.log", std::ios::app);
      SYSTEMTIME st;
      GetLocalTime(&st);
      char buffer[256];
      sprintf_s(buffer, "[%02d:%02d:%02d] %s", st.wHour, st.wMinute, st.wSecond, message);
      log << buffer;
      if (error != 0) {
          log << " (Error: " << error << ")";
      }
      log << "\n";
      log.close();
  }

  int main(int argc, char* argv[]) {
      Log("Wrapper starting");

      // Build command line for RedEdr.exe
      std::string cmdLine = "C:\\RedEdr\\RedEdr.exe -e -g -k --web -d";
      Log("Command line prepared");

      // Setup startup info
      STARTUPINFOA si = { sizeof(si) };
      si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
      si.wShowWindow = SW_HIDE;

      Log("Creating NUL handle");
      SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
      HANDLE hNull = CreateFileA("NUL", GENERIC_READ | GENERIC_WRITE,
                                  FILE_SHARE_READ | FILE_SHARE_WRITE,
                                  &sa, OPEN_EXISTING, 0, NULL);

      if (hNull == INVALID_HANDLE_VALUE) {
          Log("Failed to open NUL", GetLastError());
          return 1;
      }

      si.hStdInput = hNull;
      si.hStdOutput = hNull;
      si.hStdError = hNull;

      PROCESS_INFORMATION pi = { 0 };

      Log("Calling CreateProcess");

      // Create process
      BOOL result = CreateProcessA(
          NULL,
          (LPSTR)cmdLine.c_str(),
          NULL,
          NULL,
          TRUE,  // Inherit handles
          CREATE_NO_WINDOW,
          NULL,
          "C:\\RedEdr",
          &si,
          &pi
      );

      DWORD lastError = GetLastError();

      CloseHandle(hNull);

      if (!result) {
          Log("CreateProcess FAILED", lastError);
          return lastError;
      }

      Log("CreateProcess SUCCESS");
      char pidBuf[64];
      sprintf_s(pidBuf, "Process ID: %d", pi.dwProcessId);
      Log(pidBuf);

      // Don't wait - let it run independently
      CloseHandle(pi.hProcess);
      CloseHandle(pi.hThread);

      Log("Wrapper exiting normally");
      return 0;
  }