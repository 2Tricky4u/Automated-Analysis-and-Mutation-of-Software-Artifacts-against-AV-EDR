 #include <windows.h>

#include <string>

#include <fstream>

void Log(const char * message, DWORD error = 0) {
    std::ofstream log("C:\\RedEdr\\wrapper.log", std::ios::app);
    SYSTEMTIME st;
    GetLocalTime( & st);
    char buffer[256];
    sprintf_s(buffer, "[%02d:%02d:%02d] %s", st.wHour, st.wMinute, st.wSecond, message);
    log << buffer;
    if (error != 0) {
        log << " (Error: " << error << ")";
    }
    log << "\n";
    log.close();
}

int main(int argc, char * argv[]) {
    Log("Wrapper starting");

    // Build command line for RedEdr.exe
    std::string cmdLine = "C:\\RedEdr\\RedEdr.exe -e -g -k --web -d";
    Log("Command line prepared");

    // Setup startup info - minimal configuration for PPL
    STARTUPINFOA si = {
        sizeof(si)
      };
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    // Don't redirect handles - causes issues in PPL context
    si.hStdInput = NULL;
    si.hStdOutput = NULL;
    si.hStdError = NULL;

    PROCESS_INFORMATION pi = {
        0
      };

    Log("Calling CreateProcess");

    // Create process - NO handle inheritance for PPL compatibility
    BOOL result = CreateProcessA(
      NULL, // lpApplicationName
      (LPSTR) cmdLine.c_str(), // lpCommandLine
      NULL, // lpProcessAttributes
      NULL, // lpThreadAttributes
      FALSE, // bInheritHandles - FALSE for PPL!
      CREATE_NO_WINDOW, // dwCreationFlags
      NULL, // lpEnvironment
      "C:\\RedEdr", // lpCurrentDirectory
      &
      si, // lpStartupInfo
      &
      pi // lpProcessInformation
    );

    DWORD lastError = GetLastError();

    if (!result) {
        Log("CreateProcess FAILED", lastError);
        return lastError;
    }

    Log("CreateProcess SUCCESS");
    char pidBuf[64];
    sprintf_s(pidBuf, "Process ID: %d", pi.dwProcessId);
    Log(pidBuf);

    // Don't wait - let it run independently
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    Log("Wrapper exiting normally");
    return 0;
}